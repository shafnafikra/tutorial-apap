package apap.tutorial.isPalindrome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IsPalindromeApplication {

	public static void main(String[] args) {
		SpringApplication.run(IsPalindromeApplication.class, args);
	}

}
