package apap.tutorial.isPalindrome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsPalindromeApplicationTests {

	@Test
	void contextLoads() {
	}

}
